import { AntDesign } from '@expo/vector-icons';

export type Icon = ReturnType <typeof AntDesign>